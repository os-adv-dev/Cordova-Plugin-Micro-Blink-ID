//
//  MBMicroblinkInitialization.h
//  Pdf417Mobi
//
//  Created by Jura Skrlec on 30/01/2018.
//

#ifndef MBMicroblinkInitialization_h
#define MBMicroblinkInitialization_h

#define MB_INIT \
- (instancetype)init NS_DESIGNATED_INITIALIZER; \

#define MB_INIT_UNAVAILABLE \
- (instancetype)init NS_UNAVAILABLE; \

#endif /* MBMicroblinkInitialization_h */
